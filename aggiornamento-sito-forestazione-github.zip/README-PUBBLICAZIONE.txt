AGGIORNAMENTO SITO — FORESTAZIONE URBANA

Questo archivio è un aggiornamento da sovrapporre al repository esistente, NON una copia completa del sito.

Pubblicazione consigliata:
1. Aprire https://github.com/verdireticiviche-cloud/rovigo
2. Selezionare il branch main.
3. Caricare i file e le cartelle di questo archivio nella ROOT del repository (non caricare l’archivio ZIP come singolo file).
4. Non eliminare assets/css/, assets/js/, assets/img/ né le pagine già presenti: index.html e le pagine nuove li richiamano.
5. Verificare che index.html resti nella root e mantenere .nojekyll.
6. Attendere il deploy di GitHub Pages e controllare la home e forestazione-urbana.html.

Nota: l’archivio contiene anche carousel-6-slide.zip, utile come download; le sei immagini del carosello sono incluse anche singolarmente.
